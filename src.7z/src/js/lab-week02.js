import { createSection } from "./input-component_lab_week02.js";

createSection(document.body);
