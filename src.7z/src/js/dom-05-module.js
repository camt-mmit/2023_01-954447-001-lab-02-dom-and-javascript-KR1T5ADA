import { createComponent } from "./input-component.js";

createComponent(document.body);
